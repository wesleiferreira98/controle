"""
e um objeto que percores valores de uma colecao
itcar=iter(carros)
print(next(itcar))
e assim que implementamos um iterators
"""
carros=["GOl","corsa","147","Opala","Fusca"]
itcar=iter(carros)
while itcar:
    try:
        print(next(itcar))
    except StopIteration:
        print("Fim da lista")
        break
