import sqlite3
from sqlite3 import Error
import os

c="s"
while(c=="S" or c=="s"):
    os.system("clear")
    valor1=input("Digite a ID do seu contato: ")
    valor2=input("Digite o nome do seu contato: ")
    valor3=input("Digite o email do seu contato: ")
    valor4=input("Digite o telefone do seu contato: ")
    con= sqlite3.connect('agenda2')
    cursor=con.cursor()
    cursor.execute('INSERT INTO TB_CONTATOS (N_IDCONTATO, T_NOMECONTATO, T_TELEFCONTATO, T_EMAILCONTATO) VALUES (?,?,?,?)', (valor1, valor2, valor3,valor4))
    con.commit()
    c=raw_input("Mais ????")





def deletar(con,sql):
    try:
        cursor=con.cursor()
        cursor.execute()
        cursor.commit()
        print("Registro apagado")
    except Error as ex:
        print(ex)

cur='DELETE INTO TB_CONTATOS WHERE (N_IDCONTATO, T_NOMECONTATO, T_TELEFCONTATO, T_EMAILCONTATO) VALUES (?,?,?,?)', (valor1, valor2, valor3,valor4)


def atualizar(con,sql):
    try:
        cursor=con.cursor()
        cursor.execute()
        cursor.commit()
        print("Registro atualizado")
    except Error as ex:
        print(ex)
cur='UPDATE  TB_CONTATOS  SET N_IDCONTATO, T_NOMECONTATO='WESLEI', T_TELEFCONTATO='1212121212', WHERE N_IDCONTATO=1'

def consulta(con,sql):

        cursor=con.cursor()
        cursor.execute(sql)
        res=cursor.fetchall()
        return res


cur='SELECT * FROM TB_CONTATOS WHRE N_IDCONTATO=1'
cur='SELECT * FROM TB_CONTATOS WHRE T_NOMECONTATO LIKE '%we''
re=consulta()

for e in re:
    print(e)
