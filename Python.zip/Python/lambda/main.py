# funcoes lambda e uma funcao simples e tem a forma de declaracao simples e sua sinxate e:
# r=lambda a,b:a+b a+b e a exprecao ou seja o que a funcao lambda faz
# (lambda d,f:d+f)(3,4) dessa forma podemos associar a funcao lambda diretamente sem uso de variavel.
# print((lambda d,f:d+f)(3,4)) dessa forma imprimimos o resultado da soma

r=lambda a,b:a+b
mul=lambda a,b,c:(a+b)*c
print("O resultado e: "+str(r(2,3)))
print("O resultado e: "+str(mul(2,3,5)))

print((lambda d,f:d+f)(3,4))

df=lambda x,func:x+func(x)
res=df(4,lambda x:x*x)
print(res)

res=df(4,lambda x:x+x)
print(res)

