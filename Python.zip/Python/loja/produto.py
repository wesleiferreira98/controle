

class produto:
    def __init__(self):
        self.nome=" "
        self.fabricante=" "
        self.fornecedor=" "
        self.categoria=" "
    def set_dados(self):
            self.nome=input('Digite o nome do produto')
            self.fabricante=input('Digite o fabricante do produto')
            self.fornecedor=input('Digite o fornecedor do produto')
            self.categoria=input('Digite a categoria do produto')
    def print_dados(self):
            print("------------------------------------------------")
            print("O nome do produto......: "+str(self.nome))
            print("O fabricante do produto: "+str(self.telefone))
            print("O fornecedor do produto: "+str(self.email))
            print("A categoria do produto.: "+str(self.end))
