import os
import sqlite3
from sqlite3 import Error
def conexaobanco():
    caminho="loja_banco"
    con=None
    try:
        con=sqlite3.connect(caminho)
    except Error as ex:
        print(ex)
    return con



vcon=conexaobanco()
def query(cb,sql):
    try:
        c=cb.cursor()
        cb.execute(sql)
        cb.commit()
    except Error as ex:
        print(ex)
    finally:
        print("Operação realizada com sucesso")

def consutar(cb,sql):
    c=cb.cursor()
    cb.execute(sql)
    res=c.fetchall
    yield res




def mConsultarnomecli():
    vnome=input("Digite o nome ")
    vsql="SELECT * FROM tb_clientes  WHERE nome_cliente LIKE  '%"+vnome+"%'"
    res=consutar(vcon,vsql)
    vlim=10
    vcont=0
    for i in consutar(vcon,vsql):
        print(i)
        vcont+=1
        if(vcont>=vlim):
            vcont=0
            er=input("Aperte qualquer tecla")
            os.system("clear")
        print("Fim da lista")
        er=input("Aperte enter")
def mConsultarnomepro():
    vnome=input("Digite o nome ")
    vsql="SELECT * FROM tb_produtos  WHERE nome_produto LIKE  '%"+vnome+"%'"
    res=consutar(vcon,vsql)
    vlim=10
    vcont=0
    for i in next(res):
        print(i)
        vcont+=1
        if(vcont>=vlim):
            vcont=0
            er=input("Aperte qualquer tecla")
            os.system("clear")
        print("Fim da lista")
        er=input("Aperte enter")

def mAtualizarcli():
    os.system("clear")
    vid=str(input("Digite o ID do cliente: "))
    r=consutar(vcon,"SELECT * FROM tb_clientes WHERE id_clientes="+vid)
    vnome=input("Digite o nome do cliente")
    vtel=input("Digite o telefone")
    vemail=input("Digite o email")
    vend=input("Digite o endereco do cliente")

    vsql="UPDATE FROM tb_clientes SET nome_cliente='"+vnome+"',telefone_clientes='"+vtel+"',email_cliente='"+vemail+"', end_cliente='"+vend+"' WHERE id_clientes= "+vid
    query(vcon,vsql)
def mAtualizarpro():
    os.system("clear")
    vid=str(input("Digite o ID do produto: "))
    r=consutar(vcon,"SELECT * FROM tb_produtos WHERE id_produtos="+vid)
    vnome=input("Digite o nome do produto: ")
    vfab=input("Digite o fabricante: ")
    vfor=input("Digite o fornecedor: ")
    vcad=input("Digite a categoria do produto: ")


    vsql="UPDATE FROM tb_clientes SET nome_produto='"+vnome+"',fab_produto='"+vfab+"',for_produto='"+vfor+"', categoria='"+vcad+"' WHERE id_produtos= "+vid
    query(vcon,vsql)

def mcadastrarcli():
    os.system("clear")
    vnome=input("Digite o nome do cliente: ")
    vtel=input("Digite o telefone: ")
    vemail=input("Digite o email: ")
    vend=input("Insira o endereço do cliente: ")
    vsql="INSERT INTO tb_clientes (nome_cliente,telefone_clientes,email_cliente,end_cliente) VALUES ('"+vnome+"','"+vtel+"','"+vemail+"','"+vend+"')"
    query(vcon,vsql)
def mcadastrarpro():
    os.system("clear")
    vnome=input("Digite o nome do produto: ")
    vfab=input("Digite o fabricante do produto: ")
    vfor=input("Digite o fornecedor do produto: ")
    vcat=input("Insira a categoria do produto: ")
    vsql="INSERT INTO tb_produtos (nome_produto,fab_produto,for_produto,categoria) VALUES ('"+vnome+"','"+vfab+"','"+vfor+"','"+vcat+"')"
    query(vcon,vsql)
def mDeletarcli():
    os.system("clear")
    vid=str(input("Digite o ID do cliente: "))
    vsql="DELETE FROM tb_clientes WHERE id_clientes="+vid
    query(vcon,vsql)
def mDeletarpro():
    os.system("clear")
    vid=str(input("Digite o ID do cliente: "))
    vsql="DELETE FROM tb_produtos WHERE id_produtos="+vid
    query(vcon,vsql)
def mConsultarcli():
    print()
def mConsultarpro():
    print()
def menuPrincipal():
    os.system('clear')
    print("1- Inserir novo cliente: ")
    print("2- Inserir novo produto: ")
    print("3- Deletar cliente: ")
    print("4- Deletar produto: ")
    print("5- Consultar produto: ")
    print("6- Consultar cliente: ")
    print("7- Atualizar cliente: ")
    print("8- Atualizar produto: ")
    print("9- Sair")
#"ID:{0:_<3} Nome:{1:_<30} Fabricante:{2:_<14} Fornecedor:{3:_<30} Categoria:{4:_<30}".format(i()[0],i()[1],i()[2],i()[3],i()[4]
