
class cliente:
    def __init__(self):
        self.nome=" "
        self.telefone=" "
        self.email=" "
        self.end=" "
    def set_dados(self):
            self.nome=input('Digite o nome do cliente')
            self.telefone=input('Digite telefone do cliente')
            self.email=input('Digite o email do cliente')
            self.end=input('Digite o endereço do cliente')
    def print_dados(self):
            print("------------------------------------------------")
            print("O nome do cliente....: "+str(self.nome))
            print("O telefone do cliente: "+str(self.telefone))
            print("O email do cliente...: "+str(self.email))
            print("O endereço do cliente: "+str(self.end))
