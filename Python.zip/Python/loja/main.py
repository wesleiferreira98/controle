from cliente import cliente
from conexao import conexao
from produto import produto
from  funcoes import menuPrincipal,mcadastrarcli,mcadastrarpro,mAtualizarcli,mAtualizarpro,mDeletarcli,mDeletarpro,mConsultarnomecli,mConsultarnomepro
import os
opc=0
while(opc != 9):
    menuPrincipal()
    opc=int(input("Digite sua opcao: "))
    if(opc==1):
        mcadastrarcli()
    elif(opc==2):
        mcadastrarpro()
    elif(opc==3):
        mDeletarcli()
    elif(opc==4):
        mDeletarpro()
    elif(opc==5):
        mConsultarnomepro()
    elif(opc==6):
        mConsultarnomecli()
    elif(opc==7):
        mAtualizarcli()
    elif(opc==8):
        mAtualizarpro()
    elif(opc==9):
        os.system("clear")
        print("Programa finalizado")

    else:
        os.system("clear")
        print("opção invalida")
        er=input("Digite qualquer tecla para continuar")
er=input("Digite qualquer tecla para continuar")


