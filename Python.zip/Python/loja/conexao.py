import sqlite3
from sqlite3 import Error
class conexao:
    def conexao(self):
        self.banco=" "
        self.cb

    def conexao_banco(self):
        self.banco="loja_banco"
        self.con=None

        self.con=sqlite3.connect(self.banco)

        return self.con



    def inserir(self,cb,sql):

            self.c=self.cb.cursor()
            self.c.execute(sql)
            self.con.commit()
            print("Registro inserido")


