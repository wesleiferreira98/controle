import json
"""
carros_json='{"marca":"honda", "modelo":"HRV","cor":"azul"}'

carros=json.loads(carros_json)

for x,y in carros.items():
	print(x + " : "+ y)
"""
carro={"marca":"honda", "modelo":"HRV","cor":"azul"}

carros_json=json.dumps(carro)
print(carro)