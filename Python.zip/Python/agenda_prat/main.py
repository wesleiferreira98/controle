from  funcoes import menuPrincipal,mcadastrar,mAtualizar,mConsultar,mConsultarnome
import os
opc=0
while(opc != 6):
    menuPrincipal()
    opc=int(input("Digite sua opcao: "))
    if(opc==1):
        mcadastrar()
    elif(opc==2):
        mDeletar()
    elif(opc==3):
        mAtualizar()
    elif(opc==4):
        mConsultar()
    elif(opc==5):
        mConsultarnome()
    elif(opc==6):
        os.system("clear")
        print("Programa finalizado")

    else:
        os.system("clear")
        print("opção invalida")
        er=input("Digite qualquer tecla para continuar")
er=input("Digite qualquer tecla para continuar")
