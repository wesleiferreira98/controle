import os
import sqlite3
from sqlite3 import Error
def conexaobanco():
    caminho="agenda2"
    con=None
    try:
        con=sqlite3.connect(caminho)
    except Error as ex:
        print(ex)
    return con



vcon=conexaobanco()
def query(cb,sql):
    try:
        c=cb.cursor()
        cb.execute(sql)
        cb.commit()
    except Error as ex:
        print(ex)
    finally:
        print("Operação realizada com sucesso")
        #cb.close()
def consutar(cb,sql):
    c=cb.cursor()
    cb.execute(sql)
    res=c.fetchall
    #cb.close()
    return res



def mConsultarnome():
    print()

def mAtualizar():
    print()

def mcadastrar():
    os.system("clear")
    vnome=input("Digite o nome do amigo")
    vtel=input("Digite o telefone")
    vemail=input("Digite o email")
    vsql="INSERT INTO TB_CONTATOS (T_NOMECONTATO,T_TELEFCONTATO,T_EMAILCONTATO) VALUES ('"+vnome+"','"+vtel+"','"+vemail+"')"
    query(vcon,vsql)
def mDeletar():
    print()
def mConsultar():
    print()
def menuPrincipal():
    os.system('clear')
    print("1- Inserir novo registro")
    print("2- Deletar  registro")
    print("3- Atualizar registro")
    print("4- Consultar registro")
    print("5- Consultar registro por nome")
    print("6- Sair")
