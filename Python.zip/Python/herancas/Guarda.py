from NPC import NPC

class Guarda(NPC):
    def carat():
        self.forca=400
        self.municao=200

