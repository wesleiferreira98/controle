from NPC import NPC

class elite(NPC):
    def carat(self):
        self.forca=400
        self.municao=200
