from NPC import NPC

class soldado(NPC):
    def carat(self):
        self.forca=400
        self.municao=200

