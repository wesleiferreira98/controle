from Guarda import Guarda

s1=Guarda()
s1.carat()

