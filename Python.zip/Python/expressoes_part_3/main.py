"""
Split = divide uma string e retorna uma coleçao com essas divisoes.
essa e sua forma de uso: re.split("",texto) antes da virgula e colocado o divisor e depois da mesma e
colocado em qual varivael sera feita a divisao que nesse caso e o texto.

"""
import re

texto="Curso de python feito em Linux-Mint 19.3 tricia"

res=re.split(" ",texto)

print(res)

for i in res:
    print(i)
