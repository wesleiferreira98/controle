import os
os.system('clear')
num=input("Digite um numero")
num2=input("Digite outro numero")
if num2==0:
    raise Exception("Valor 0 nao permitido")
else:
    res=num/num2
print("O valor da divisao entre " + str(num) + " e " + str(num2) + " = " + str(res))
