import os
import sqlite3
from sqlite3 import Error
def conexaobanco():
    caminho="agenda2"
    con=None
    try:
        con=sqlite3.connect(caminho)
    except Error as ex:
        print(ex)
    return con



vcon=conexaobanco()
def query(cb,sql):
    try:
        c=cb.cursor()
        cb.execute(sql)
        cb.commit()
    except Error as ex:
        print(ex)
    finally:
        print("Operação realizada com sucesso")
        #cb.close()
def consutar(cb,sql):
    c=cb.cursor()
    cb.execute(sql)
    res=c.fetchall
    #cb.close()
    return res



def mConsultarnome():
    vnome=input("Digite o nome ")
    vsql="SELECT * FROM TB_CONTATOS  WHERE T_NOMECONTATO LIKE  '%"+vnome+"%'"
    res=consutar(vcon,vsql)
    vlim=10
    vcont=0
    for i in res:
        print("ID:{0:_<3} Nome:{1:_<30} Telefone:{2:_<14} E-mail:{3:_<30}".format(r[0],r[1],r[2],r[3]))
        vcont+=1
        if(vcont>=vlim):
            vcont=0
            er=input("Aperte qualquer tecla")
            os.system("clear")
        print("Fim da lista")
        er=input("Aperte enter")

def mAtualizar():
    os.system("clear")
    vid=str(input("Digite o ID do amigo: "))
    r=consutar(vcon,"SELECT * FROM TB_CONTATOS WHERE N_IDCONTATO="+vid)
    rnome=r[0][1]
    rtel=r[0][2]
    remail=r[0][3]
    vnome=input("Digite o nome do amigo")
    vtel=input("Digite o telefone")
    vemail=input("Digite o email")
    if(len(vnome)==0):
        vnome=rnome
    if(len(vtel)==0):
        vtel=rtel
    if(len(vemail)==0):
        vemail=remail

    vsql="UPDATE FROM TB_CONTATOS SET T_NOMECONTATO='"+vnome+"',T_TELEFCONTATO='"+vtel+"',T_EMAILCONTATO='"+vemail+"' WHERE N_IDCONTATO= "+vid
    query(vcon,vsql)

def mcadastrar():
    os.system("clear")
    vnome=input("Digite o nome do amigo")
    vtel=input("Digite o telefone")
    vemail=input("Digite o email")
    vsql="INSERT INTO TB_CONTATOS (T_NOMECONTATO,T_TELEFCONTATO,T_EMAILCONTATO) VALUES ('"+vnome+"','"+vtel+"','"+vemail+"')"
    query(vcon,vsql)
def mDeletar():
    os.system("clear")
    vid=str(input("Digite o ID do amigo: "))
    vsql="DELETE FROM TB_CONTATOS WHERE N_IDCONTATO="+vid
    query(vcon,vsql)
def mConsultar():
    vsql="SELECT * FROM TB_CONTATOS"
    res=consutar(vcon,vsql)
    vlim=10
    vcont=0
    for i in res:
        print("ID:{0:_<3} Nome:{1:_<30} Telefone:{2:_<14} E-mail:{3:_<30}".format(r[0],r[1],r[2],r[3]))
        vcont+=1
        if(vcont>=vlim):
            vcont=0
            er=input("Aperte qualquer tecla")
            os.system("clear")
        print("Fim da lista")
        er=input("Aperte enter")

def menuPrincipal():
    os.system('clear')
    print("1- Inserir novo registro")
    print("2- Deletar  registro")
    print("3- Atualizar registro")
    print("4- Consultar registro")
    print("5- Consultar registro por nome")
    print("6- Sair")

opc=0
while(opc != 6):
    menuPrincipal()
    opc=int(input("Digite sua opcao: "))
    if(opc==1):
        mcadastrar()
    elif(opc==2):
        mDeletar()
    elif(opc==3):
        mAtualizar()
    elif(opc==4):
         mConsultar()
    elif(opc==5):
        mConsultarnome()
    elif(opc==6):
        os.system("clear")
        print("Programa finalizado")

    else:
        os.system("clear")
        print("opção invalida")
        er=input("Digite qualquer tecla para continuar")
er=input("Digite qualquer tecla para continuar")
