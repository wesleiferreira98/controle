import os
os.system('clear')
num1=input("Digite o primeiro valor ")
num2=input("Digite o segundo valor ")
res=num1+num2
if res>=30:
    print('Soma dos valores: '+ str(res))
    print('Voce passou.')
else:
    print('Soma dos valores: '+ str(res))
    print('Voce nao passou.')

