"""
As expressoes regulares, são como uma mini linguagem de programacao, possuem recursos para trabalhar com strings.
re.finall() retorna todas as ocorrencias encotradas dentro de uma lista string.
res=re.findall("Python",texto) assim passamos o elemento a ser pesquisado que e Python, e onde ele sera pesquisado que e
re.search("",texto) retorna a possição da primeira ocorrecia que encotrar.
na variavel texto
start() retorna a possicao inicial do elemento sua forma de uso: print("A possicao do elemento e: "+str(res.start())

end() retorna a possicao final do elemento sua forma de uso: print("A possicao do elemento e: "+str(res.end())

import re

texto="Curso de Python"

pesq=input('Digite o nome a ser pesquisado ')

res=re.findall(pesq,texto)
print(res)

qtde=len(res)

print("O tamanho da lista e: "+str(qtde))

for c in res:
    print(c)
"""

import re


texto="Curso de Python"
res=re.search("Curso",texto)
if (res != None):
    print("A possicao inicial do elemento e: "+str(res.start())

    print("A possicao final do elemento e: "+str(res.end())

else:
    print("O elemento nao esta na string")

