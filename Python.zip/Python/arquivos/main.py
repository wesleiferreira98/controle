"""
f.read(10) ler os 10 primeiros caracteres do arquivo
readline() faz leitura da linha
"""
texto="teste.sh"
arq=open(texto,"a")
txt=raw_input("Digite um nome")
arq.write(txt+"\n")

arq.close()

arq=open(texto,"r")

for i in arq:
    print(i)


arq.close()
