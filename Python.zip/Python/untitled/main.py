"""
datetime e uma biblioteca que serve para trabalhar com datas. temos os metodos
data=datetime.datetime.now() retorna data e hora do sistema.
print(str(data.day) + "/" + str(data.month) + "/" + str(data.year)) uma maneira de personalizar a data atual
nasc=datetime.datetime(1978,3,7) serve para criar uma data.
temos tambem:
    %a= retorna o dia da semana reduzido
    %A= ;;;;;;; o dia da semana completo
    %d=  numero do dia do mes
    %w= numero do dia da semana
    %b= retorna o nome do mes reduzido
    %B= retorna o nome do mes completo
    %m= retorna o numero do mes
    %y= retorna o ano com dois digitos
    %Y= retorna o ano com 4 digitos
    %H= retorna a hora com dois digitos 0 a 23h
    %I= retorna a hora com um digito 0 a 12h

"""
import datetime
data=datetime.datetime.now()
nasc=datetime.datetime(1978,3,7)
print(str(data.day) + "/" + str(data.month) + "/" + str(data.year))
print(nasc.strftime("%A"))
