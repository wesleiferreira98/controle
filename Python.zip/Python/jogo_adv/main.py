import random
import os
erros=0
sorteado=random.randrange(0,300)
jogador=input("Digite o numero a ser sorteado  de ")

while(sorteado!=jogador):
    os.system('clear')
    if(sorteado>jogador):
        print("Erro numero e maior")
    elif(sorteado<jogador):
        print("Erro numero e menor")
    erros+=1
    jogador=input("Digite o numero a ser sorteado  de 0 a 300")
print(" O numero "+ str(jogador) + ", voce acertou em " + str(erros+1) + " tentativas")
