num=num2=res=0;
canal="CFB Cursos"
def cn():
	print(canal)
	print("fim")
cn()
