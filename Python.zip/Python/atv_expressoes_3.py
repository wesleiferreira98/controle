import re

texto=input("Digite uma frase")

res=re.split(" ",texto)

for i in res:
	print(i)
	print("------------")