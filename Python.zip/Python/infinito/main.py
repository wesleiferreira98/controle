import os
os.system('clear')
carros=[]
carro=raw_input('Digite o veiculo')

while carro != "sair":
        carros.append(carro)
        carro=raw_input('Digite o veiculo')

os.system('clear')

for c in carros:
    print(c)
