carros={
    "carro1":{
        "Modelo":"Golf",
        "Cor":"Prata"


    },
    "carro2":{
        "Modelo":"Gol",
        "Cor":"Prata"



    },
    "carro3":{
        "Modelo":"Gol bola",
        "Cor":"Prata"



    }






}
moto1={
    "Modelo":"CG150",
    "Cor":"Azul",
    "Fabricante":"Honda"



}
moto2={
    "Modelo":"Intruder",
    "Cor":"Preto",
    "Fabricante":"Yamara"



}
moto3={
    "Modelo":"Titan",
    "Cor":"Verde",
    "Fabricante":"Honda"



}
motos={
    "m1":moto1,
    "m2":moto2,
    "m3":moto3


}

print(carros["carro3"])
print(motos["m1"])
