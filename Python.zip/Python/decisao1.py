a=10
b=5
op="+"
if op=="+":
    res=a+b
print("Operacao: " + str(res))