import random
num_i=10;
num_f=4.5;
num_c=1j;

num_r=[
	random.randrange(0,60),
	random.randrange(0,60),
	random.randrange(0,60),
	random.randrange(0,60),
	random.randrange(0,60),
	random.randrange(0,60)
	]
x=num_r;
print("Valor: "+ str(x[0])+" - Tipo: "+str(type(x)));
print("Valor: "+ str(x[1])+" - Tipo: "+str(type(x)));
print("Valor: "+ str(x[2])+" - Tipo: "+str(type(x)));
print("Valor: "+ str(x[3])+" - Tipo: "+str(type(x)));
print("Valor: "+ str(x[4])+" - Tipo: "+str(type(x)));
print("Valor: "+ str(x[5])+" - Tipo: "+str(type(x)));