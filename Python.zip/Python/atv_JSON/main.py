import json

with open('jogador.json') as f:
    jogador=json.load(f)


def linha():
    print("-------------------------------")

for c in jogador:
    print(c)

linha()

for i in jogador.items():
    print(i)



linha()

print(jogador["time"])

linha()

for im in jogador["mochila"]:
    print(im)


linha()

for a in jogador["aeronave"]:
    print(a["tipo"]+ " - "+str(a["habilidade"]))
