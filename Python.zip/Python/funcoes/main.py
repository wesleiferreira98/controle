"""
funcoes e um bloco de codigos que fica armazenao em uma sitaxe e podemos executar em momentos especificos.
Ou seja esse codigo so e execultado quando chamamos em um determinado momento do programa
e assim nao precisamos escrever o mesmo codigo varias vezes para executa-lo, uma outra funcionalidade e na manutencao
desse codigo, pois basta que modifiquemos o codigo da funcao que em todo lugar do codigo principal, onde a funcao e chamada,
tambem havera mudanca. Sua sitaxe e:
def somar():
    escopo
"""

def somar(n1,n2):
    r=n1+n2
    print("A soma de: "+ str(r))
def sub(n1,n2):
    r=n1-n2
    print("A soma de: "+ str(r))



somar(10,5)
sub(9,4)
