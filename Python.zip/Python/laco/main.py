carros=["HRV","GOL","Fox","Fit","GOL","Fox"]
for x in carros:
    print(x)
    if(x=="Fit"):
        break


print("Fim do programa")
