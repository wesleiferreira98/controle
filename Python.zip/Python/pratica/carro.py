import os
class carro:
    nome=""
    pot=0
    velMax=0
    ligado=False


    def __init__(self,nome,pot):
        self.nome=nome
        self.pot=pot
        self.velMax=int(pot)*2

    def ligar(self):
        self.ligado=True

    def desligar(self):
        self.ligado=False

    def info(self):
        print("Nome....................: "+self.nome)
        print("Potencia............: "+str(self.pot))
        print("Velocidade maxima: "+str(self.velMax))
        print("ligado...........: "+str(self.ligado))

