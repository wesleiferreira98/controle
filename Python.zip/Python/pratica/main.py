from carro import carro
import os
carros=[]


def Menu():
    os.system("clear") or None
    print("1 - Novo carro")
    print("2 - informacoes do carro")
    print("3 - Excluir carro")
    print("4 - Ligar o carro")
    print("5 - Desligar o carro ")
    print("6 -  Listar os carros")
    print("7 - Sair")


def NovoCarro():
    n=raw_input("Nome do carro: ")
    p=input("Potencia do carro: ")
    car=carro(n,p)
    carros.append(car)
    print("Carro criado")
    a=raw_input("Aperte ENTER para continuar")
def informacoes():
     os.system("clear") or None
     n=input("Digite o numero do carro a ser procurado:" )
     try:
         carros[int(n)].info()
     except:
         print("Carro nao existe na lista")
     a=raw_input("Aperte ENTER para continuar")
def Excluir():
    os.system("clear") or None
    n=input("Digite o numero do carro a ser excluido:" )
    try:
         del carros[int(n)]
    except:
        print("Carro nao existe na lista")
    a=raw_input("Aperte A para continuar")


def carliga():
    os.system("clear") or None
    n=input("Digite o numero do carro a ser ligado:" )
    try:
        carros[int(n)].ligar()
    except:
       print("Carro nao existe na lista")
    a=raw_input("Aperte ENTER para continuar")




def cardesliga():
     os.system("clear") or None
     n=input("Digite o numero do carro a ser ligado:" )
     try:
        carros[int(n)].desligar()
     except:
        print("Carro nao existe na lista")
     a=raw_input("Aperte ENTER para continuar")

def listarCarros():
    os.system("clear") or None
    for c in carros:
        print(c.nome)
    a=raw_input("Aperte ENTER para continuar")





Menu()
opc=input("Digite sua opcao")
while opc != 7:
    if opc == 1:
        NovoCarro()
    elif opc == 2:
        informacoes()
    elif opc == 3:
        Excluir()
    elif opc == 4:
        carliga()
    elif opc == 5:
        cardesliga()
    elif opc == 6:
        listarCarros()
    Menu()
    opc=input("Digite sua opcao")
os.system("clear") or None
print("Programa finalizado")
