"""
try examina um bloco especificado e retorna um erro caso encontre um.
except recebe o erro de try e execulta uma rotina de execessao, ou seja so e execultado se try retornar um erro.
finally ocorre  independetenmente do erro, ou seja executa se try retornar um erro ou nao. Sua sitaxe
x=10
try:
    print(x)
except:
    print("Erro")

else:
    print("Tudo certo")
finally:
    print("Fim do tratamento")
else so sera execultado quanto o try nao retornar um erro.
raise gera uma execessao caso o DEV queira.
"""
num=10
if not type(num) is int:
    raise Exception("Somente numeros inteiros")
else:
    print("O numero inteiro permitido e: "+str(num))
