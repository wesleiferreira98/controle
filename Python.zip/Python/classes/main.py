from carro import carro
c1=carro()
c1.set_dados()
c1.print_dados()
a=c1.ret_preco()
print("O preco corrigido e: "+str(a))
print("---------------------------------")
c1.andar()

