
class veiculos:
    def __init__(self):
        self.num_rodas=0
        self.modelo=" "
        self.preco=0.0
        self.cor="  "
        self.estado=False
    def set_dados(self):
            self.modelo=raw_input('Digite o modelo do carro')
            self.cor=raw_input('Digite a cor do carro')
            self.preco=input('Digite o preco do carro')
            self.num_rodas=input('Digite o numero de rodas do  carro')
    def print_dados(self):
            print("------------------------------------------------")
            print("O modelo do carro: "+self.modelo)
            print("O preco do carro: "+str(self.preco))
            print("O numero de rodas do carro: "+str(self.num_rodas))
            print("A cor do carro: "+self.cor)
    def ret_preco(self):
            return self.preco*2
    def andar(self):
            if(self.estado):
                print("Andando")
            else:
                print("Parado")
