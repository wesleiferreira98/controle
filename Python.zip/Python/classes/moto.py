from veiculos import veiculos

class moto:
    def ret_preco(self):
        print("O preco do carro e: "+str(self.preco*43))
