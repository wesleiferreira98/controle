# self serve como uma passegem de parametros para propria classe como o this em outras liguagens
from veiculos import veiculos
class carro(veiculos):
    def ret_preco(self):
        print("O preco do carro e: "+str(self.preco*123))





