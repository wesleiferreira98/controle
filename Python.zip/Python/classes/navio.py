from veiculos import veiculos

class navio:
    def ret_preco(self):
        print("O preco do carro e: "+str(self.preco*1213))
