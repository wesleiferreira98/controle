import canal


canal.nome()
print(canal.jogador["nome"])

