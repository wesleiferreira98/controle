def nome():
    print("Weslei")
jogador={
    "nome":"Bruce",
    "pontos":100,
    "energia":20,
    "time":1




}
