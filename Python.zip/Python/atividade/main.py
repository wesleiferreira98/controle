carros=[[],[],[]]
carro=raw_input('Digite o nome do veiculo')
while carro != "sair":
    carros.append(carro)
    carro=raw_input('Digite o nome do veiculo')
for c in carros:
    print(c)
print('Fim do programa')
