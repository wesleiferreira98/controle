"""
a colecao Dictionary e uma colecao aberta ou seja, podemos inserir, auterar remover os valores de forma direta,
o que nao e possivel em uma tupla por exemplo nos Dictionary trabalhamos com chaves {}, no modelo chave valor.
a sitaxe e a seginte: carro={Fabricante:Honda} chave/key - valor/value.
para imprimir somente um valor podemos usar a segunte sitaxe: print(carro[Modelo]), para imprimir o valor HRV.
para mudar o valor do Dictionary usamos isso: carro[cor]=azul.
len(carro) retorna o tamanho do Dictionary.
usamos carro[Cambio]=Automatico para adicionar chaves e valores no Dictionary.
usamos carro.pop("Cambio") para remover a chave cambio e o valor a ela acociada.
for x in carro:
    print(x) usamos essa sitaxe para percorrer as chaves do Dictionary.
    print(carro[x]) usamos essa sitaxe para percorrer os valores do Dictionary.
ou podemos usar a seguinte sitaxe para imprimir chaves e valores de maneira organizada.
for c,v in carro.items():
    print(c + ": " + v)
"""
carro={"Fabricante":"Honda","Modelo":"HRV","Ano":"2016","Cor":"prata"}
print(carro["Modelo"])
carro["Cor"]="Azul"
carro["Cambio"]="Automatico"
carro.pop("Cambio")
if "Modelo" in carro:
    print("Sim esse valor esta na chave")
for c,v in carro.items():
    print(c + ": " + v)


