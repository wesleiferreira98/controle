clima="Sol"
lugar=""
din=100
if clima=="Sol" and (din>=300 and din<=500):
    lugar="clube"
else:
    lugar="casa"


print("Vou ao "+ lugar)
