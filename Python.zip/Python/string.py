curso="Curso de python"

print(curso.upper())
print("Tamanho: "+ str(len(curso)))