class NPC:
    def __init__(self,nome,time,forca,municao):
        self.nome=nome
        self.time=time
        self.forca=forca
        self.municao=municao
        self.vivo=True
        self.energia=100
    def info(self):
        print("Nome......:" + self.nome)
        print("Time......:" + str(self.time))
        print("Forca.....:" + str(self.forca))
        print("Municao...:" + str(self.municao))
        print("Vivo......:" + ("sim" if self.vivo else "nao"))
        print("Energia...:" + str(self.energia))
        print("------------------------------------------------")
class soldado(NPC):
    def __init__(self,nome,time):
        self.forca=200
        self.municao=200
        super().__init__(nome,time,self.forca,self.municao)
class Guarda(NPC):
    def __init__(self,nome,time):
        self.forca=200
        self.municao=200
        super().__init__(nome,time,self.forca,self.municao)
class elite(NPC):
    def __init__(self,nome,time):
        self.forca=400
        self.municao=200
        super().__init__(nome,time,self.forca,self.municao)

s1=Guarda("Olho vivo",1)
s2=soldado("bala na agulha",2)
s3=elite("Ninja",3)
