"""
JSON essa e a sua forma de implementação:
    carro_json='{"marca":"modelo", "modelo":"HRV", "cor":"prata"}'

import json
carro_json='{"marca":"modelo", "modelo":"HRV", "cor":"prata"}'
carros=json.loads(carro_json) este metodo converte de um json para um dicionario

for x,y in carros.items():
    print(x + " : "+ y)
carros_json=json.dumps(carro):  este metodo converte um dicionario em um json

Quando convertemos uma lista ou uma tupla em json este vira em um array json.
indent=4 define a identação nos espaços identificados.

"""
import json

carros_dictionary={"marca":"modelo", "modelo":"HRV", "cor":"prata"}
carros_json=json.dumps(carros_dictionary)
print(carros_json)

carros_list=["honda","VW","Ford","fiat","CH"]
carros_tupla=("honda","VW","Ford","fiat","CH")

carros_of=json.dumps(carros_dictionary,indent=4,separators=(":","="),sort_keys=True)
print(carros_of)
