carros=["HRV","Golf","Argo","Focus"]
carros[3]="GOl bola"
carros.append("Fit")
carros.append("celta")
carros.append("gol quadrado")
carros.append("HB20")
carros2=["Fusca","Fiat 147","Opala","Brasilia","Tempra"]
carros3=carros+carros2
print(carros3)
print(str(len(carros3)) + " quantidade de carros na lista")



