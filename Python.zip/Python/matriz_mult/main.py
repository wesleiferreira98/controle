# a matriz e uma colecao de lista que usa dois indices de linha e coluna.
# E e criada da seguinte forma: carros=[[Modelo, HRV],[Fabricante, Honda],[Ano, 2019]]
carros=[
       ["Modelo", "HRV"],
       ["Fabricante", "Honda"],
       ["Ano", 2019]
]
carros[2][1]=2020
for l,c in carros:
    print("Linha: " + l + " | Coluna: " + str(c) + "\n")
