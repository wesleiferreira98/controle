def linha():
    print("--------------------------------------")


a1=input("digite um numero: ")
b=input("digite um numero: ")
c=input("digite um numero: ")
r=lambda a,b,g:(a+b)*g
print("O resultado e: "+str(r(a1,b,c)))
linha()
print("A soma e "+str((lambda d,f,r:d+f+r)(a1,b,c)))
linha()
j=lambda a,fucn:a+fucn(a)
res= j(a1, lambda a:a*a)
print("A resultado e: "+str(res))
