carros=["Fucas","147","Opala","corsa"]
itcar=iter(carros)
while itcar:
    try:
        print(next(itcar))
    except StopIteration:
        break
