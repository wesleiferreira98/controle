tu_carros=("HRV","GOlf","Gol bola")
lis_carros= list(tu_carros)
lis_carros[2]="Fusca"
tu_carros=tuple(lis_carros)
for c in tu_carros:
    print(c)
# na criacao de tuplas utilizamos () ao inves de [].
# na tupla de diferente da lista nao podemos modificar os elementos que estao dentro do () de forma direta.
# so e possivel fazer esse tipo de modificacao se covertermos a tupla em lista como no exemplo abaixo;
# lis_carros= list(tu_carros) nesse caso usamos uma operacao de cast para fazer tal conversao.
# tu_carros=tuple(lis_carros) nessa caso convetemos a lista em tupla com uma operacao de cats.
