import random
import os
sorteado=random.randrange(1,100)
jogador=input("Digite o seu numero: ")
erro=0
while sorteado != jogador:
    os.system('clear')
    if jogador>sorteado:
        print("Erro o seu numero e maior "+ str(sorteado))
    elif jogador<sorteado:
        print("Erro o seu numero e menor")
    erro+=1
    jogador=input("Digite o seu numero: ")
print("Voce acertou em " + str(erro+1) + ", tentativas")
