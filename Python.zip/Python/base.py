num1=10
num2="weslei"
num3=1
print(num2)
print(num1+num3)


if 10> 12:
	print("maior")
print("fim")
