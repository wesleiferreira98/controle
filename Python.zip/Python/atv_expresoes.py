import re
c='s'
carros=[]
while(c=='S' or c=='s'):

	carro=input("Digite um nome de um carro ")
	

	c=input("Deseja continuar ? [S/s] ")


pes=input("Digite o nome do carro a ser pesquisado ")


rea= re.search(pes,carro)

if(rea != None):
	print(rea)

else:
	print("Elemento nao encotrado.")

