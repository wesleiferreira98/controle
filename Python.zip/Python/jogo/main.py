import funcoes
jogarNovamente="s"
while jogarNovamente(jogarNovamente=="s" or jogarNovamente=="S"):
    while True:
        tela()
        jogadorJoga()
        cpuJoga()
        tela()
        verificarVitoria()
        if (verificarVitoria()!="n"or Jogadas>=maxJogadas):
            break
    print("Fim do jogo")
    if(vit=="X" or vit=="O"):
        print("Resultado: Jogador "+ vit + " venceu")
    else:
        print("Deu empate entre os jogadores.")
    jogarNovamente=input("Deseja jogar jogarNovamente ? [S/n]")
    redefinir()
