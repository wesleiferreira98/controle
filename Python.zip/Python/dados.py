
x=["Carro","Aviao","navio","moto",1,58.3,True]
x=("Carro","Aviao","navio","moto",1,58.3,True)
x={
	"canal":"CFB Cursos",
	"Cursos":"Curso de Python",
	"nome":"Weslei"
}
x={5,4,2,1,3,6}
x=frozenset({5,4,2,1,3,6})
print("Valor: "+str(x))
print("Tipo: "+str(type(x)))
#Diferente do array a tupla é fechada, ou seja não podemos adicionar novos itens fora dela
#EX: x=("Carro","Aviao","navio","moto",1,58.3,True) x[0]=bike isso e invalido
# x=range(0,100) esse metodo cria uma lista de 0 a 100 

#x=frozenset({5,4,2,1,3,6}) essa função bloqueia o set de forma alguma podemos auterar o set