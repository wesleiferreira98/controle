import re
import os
texto="Nomes.txt"
arq=open(texto,"a")

c='S'
while (c=='S' or c=='s'):
	cs= raw_input("Digite uma frase: ")
	arq.write(cs+"\n")

	c=raw_input("Mais ????: ")

arq.close()

arq=open(texto,"r")
res=arq.readline()

for i in arq:
	print(i)
if(os.path.exists(texto)):
	os.remove(texto)
arq.close()


