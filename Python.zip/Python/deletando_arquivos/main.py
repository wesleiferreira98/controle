import re
import os
texto="teste.sh"
arq=open(texto,"a")
txt=raw_input("Digite um nome")
arq.write(txt+"\n")

arq.close()

arq=open(texto,"r")

for i in arq:
    print(i)

if (os.path.exists(texto)):
    os.remove(texto)
arq.close()
