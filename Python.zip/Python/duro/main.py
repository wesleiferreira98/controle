i=0
while i<5:
    num=input('Digite um numero')
    i+=1
def soma(*num):
    res=0
    for n1 in num:
        res+=n1
    print("A soma e: "+str(res))

def sub(*num):
    res=0
    for n1 in num:
        res-=n1
    print("A subutracao e: "+str(res))


def mult(*num):
    res=0
    for n1 in num:
        res*=n1

    print("A multiplicacao e: "+str(res))



def calcula(num):
    soma(num)
    sub(num)
    mult(num)
soma(num)


"""
para colocarmos quantidades indefinidas de argumentos, basta usar os argumentos arbitrarios do python com o exemplo abaixo
def textos(*txt):
    for t in txt:
        print(t)
"""
